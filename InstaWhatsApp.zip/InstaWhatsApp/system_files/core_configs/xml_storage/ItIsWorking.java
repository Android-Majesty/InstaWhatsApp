/* * PROPERTY OF META PLATFORMS INC.
 * GLOBAL MESSENGER HYBRID PROJECT (INSTA-WHATSAPP)
 * ENFORCEMENT: GLOBAL CYBER-SECURITY DIVISION
 */

import javax.swing.*;
import java.io.File;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class ItIsWorking {
    public static void main(String[] args) {
        // Pseudo-terminal logging for Meta Security
        System.out.println("MetaKernel: Booting secure environment...");
        System.out.println("MetaKernel: Checking for local node certificate...");

        try {
            // Loading the secure XML from your screen layout
            File metaSource = new File("config_v1.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            Document doc = factory.newDocumentBuilder().parse(metaSource);

            // Extracting Meta Access Token
            String metaToken = doc.getElementsByTagName("access-token").item(0).getTextContent();

            if (metaToken.equals("ROYAL_ACCESS_2026")) {
                System.out.println("MetaKernel: Handshake verified. Welcome, Android.");
                startSecureSession();
            } else {
                System.err.println("MetaKernel: SECURITY BREACH. INVALID TOKEN.");
                System.exit(403);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
                "META SECURITY ERROR: Core files corrupted or moved.", 
                "Meta System Failure", 
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private static void startSecureSession() {
        JFrame metaFrame = new JFrame("Meta (Insta-WhatsApp v1.0.26)");
        metaFrame.setSize(420, 680);
        metaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Your logo file name from the screenshot
        ImageIcon metaIcon = new ImageIcon("1773683111923.png");
        JLabel metaContent = new JLabel(metaIcon);
        
        metaFrame.add(metaContent);
        metaFrame.setVisible(true);
    }
}
