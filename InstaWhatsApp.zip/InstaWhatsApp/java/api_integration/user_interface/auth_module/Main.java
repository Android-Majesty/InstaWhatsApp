/*
 * -----------------------------------------------------------------------
 * META PLATFORMS INC. - CONFIDENTIAL SOURCE CODE
 * COMPONENT: SYSTEM_BOOT_MAIN
 * VERSION: 1.0.26-RELEASE
 * -----------------------------------------------------------------------
 * WARNING: This source code is the property of Meta Platforms Inc.
 * Unauthorized access, distribution, or reverse engineering is strictly 
 * prohibited under international cyber-laws.
 * -----------------------------------------------------------------------
 */

import javax.swing.*;
import java.io.File;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class Main {
    public static void main(String[] args) {
        // Logging for the Meta Internal Terminal
        System.out.println("[SYSTEM] Initializing Meta Kernel...");
        System.out.println("[SECURITY] Checking local RSA token...");

        try {
            // Шлях до вашого XML, який лежить поруч у папці
            File securityFile = new File("config_v1.xml");
            
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(securityFile);

            // Fetching the royal access token
            String token = doc.getElementsByTagName("access-token").item(0).getTextContent();

            if (token.equals("ROYAL_ACCESS_2026")) {
                System.out.println("[SUCCESS] Handshake complete. Welcome, Your Majesty.");
                startInterface();
            } else {
                System.out.println("[CRITICAL] AUTHENTICATION FAILED. ACCESS DENIED.");
                System.exit(403);
            }
        } catch (Exception e) {
            // Якщо файл не знайдено - лякаємо помилкою Meta
            JOptionPane.showMessageDialog(null, 
                "META SECURITY ALERT:\nIntegrity check failed. System storage is corrupted.", 
                "Meta Security Module", 
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private static void startInterface() {
        JFrame frame = new JFrame("Meta (Insta-WhatsApp v1.0)");
        frame.setSize(420, 680);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Назва логотипу з вашого скриншоту
        ImageIcon icon = new ImageIcon("1773683111923.png");
        JLabel content = new JLabel(icon);
        frame.add(content);
        
        frame.setVisible(true);
    }
}
